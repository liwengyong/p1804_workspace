
def y():
    print('永')
