
def x():
    print('0.0')
