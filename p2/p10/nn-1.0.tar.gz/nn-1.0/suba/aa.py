
def l():
    print('李')
