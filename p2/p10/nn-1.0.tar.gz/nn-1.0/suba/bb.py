
def w():
    print('文')
