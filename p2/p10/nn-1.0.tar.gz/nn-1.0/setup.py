
from distutils.core import setup

setup(name='nn',version='1.0',description='this is test mod',author='nn',py_modules=['suba.aa','suba.bb','subb.cc','subb.dd'])
#from distutils.core import setup

#setup(name="xiaoyuan", version="1.0", description='xiaoyuan's module", author=“xiaoyuan", py_modules=['suba.aa', 'suba.bb', 'subb.cc', 'subb.dd'])
